﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.CustomModel
{
    public class RechargeModel
    {

        public int Id { get; set; }
        public string VehicleRegNo { get; set; }
        public decimal Amount { get; set; }
        public string TransactionId { get; set; }
        public string WLTransactionId { get; set; }
        public string FinacleReference { get; set; }
        public string ResponseCode { get; set; }
        public string ResponseMsg { get; set; }
        public bool AmountDeducted { get; set; }
        public bool RechargeSuccess { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string BranchCode { get; set; }
        public string PaymentType { get; set; }
        public string FromAccountNumber { get; set; }
        public string ToAccountNumber { get; set; }
        public string StatusName { get; set; }
        public string RechargedBy { get; set; }
        public DateTime? RechargedDate { get; set; }

        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string txnDateTime { get; set; }

    }
}