﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.CustomModel
{
    public class RegistrationModel
    {

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string DeliveryAddress { get; set; }
       public int VehicleTypeId { get; set; } 
        public string VehicleRegNo { get; set; }
        public decimal? SecurityDeposit { get; set; }
        public decimal? FastagFee { get; set; }
        public decimal? MinimumBalanceDeposit { get; set; }
        public decimal? Others { get; set; }
        public decimal? TotalPayable { get; set; }
        public bool IsDeleted { get; set; }
        public string PaymentType { get; set; }
        public string FromAccountNumber { get; set; }
        public string ToAccountNumber { get; set; }
        public string BranchCode { get; set; }
        public string FatherName { get; set; }
        public DateTime? DOB { get; set; }
        public string FinacleTransNumber { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public string ApprovedBy { get; set; }
        public string ApproverBranchCode { get; set; }
        public DateTime? ApprovedDate { get; set; }

    }

    public class RegisteredList
    {
        public int Id { get; set; }
        public string ReferenceNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string DeliveryAddress { get; set; }
        public int VehicleTypeId { get; set; }
        public string VehicleRegNo { get; set; }
        public decimal? SecurityDeposit { get; set; }
        public decimal? FastagFee { get; set; }
        public decimal? MinimumBalanceDeposit { get; set; }
        public decimal? TotalPayable { get; set; }
        public bool IsDeleted { get; set; }
        public string VehicleType { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public decimal? Others { get; set; }
        public string PaymentType { get; set; }
        public string FromAccountNumber { get; set; }
        public string ToAccountNumber { get; set; }
        public string BranchCode { get; set; }
        public string FatherName { get; set; }
        public DateTime? DOB { get; set; }
        public string FinacleTransNumber { get; set; }
        public string StatusName { get; set; }
        public string ApprovedBy { get; set; }
        public string ApproverBranchCode { get; set; }
        public DateTime? ApprovedDate { get; set; }
    }
}