﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace OrchestratorAsset.Web.CustomModel
{
    public class CreditDebitTransaction
    {
        [XmlRoot(Namespace = "http://www.finacle.com/fixml", ElementName = "FIXML", DataType = "string", IsNullable = true)]
        public class FIXML
        {
            public FIXMLHeader Header { get; set; }
            public FIXMLBody Body { get; set; }
        }

        public class FIXMLHeader
        {
            public ResponseHeader ResponseHeader { get; set; }
        }

        public class ResponseHeader
        {

            public HostTransaction HostTransaction { get; set; }

        }
        public class HostTransaction
        {
            public string Status { get; set; }

        }

        public class FIXMLBody
        {
            public XferTrnAddResponse XferTrnAddResponse { get; set; }
            public Error Error { get; set; }
        }
        public class Error
        {
           public  FIBusinessException FIBusinessException { get; set; }
        }
        public class FIBusinessException
        {
            [XmlElement("ErrorDetail")]
            public List<ErrorDetail> ErrorDetail { get; set; }
        }

        public class ErrorDetail
        {

                public string ErrorCode { get; set; }
            public string ErrorDesc { get; set; }
            public string ErrorSource { get; set; }

            public string ErrorType { get; set; }
        }

        public class  XferTrnAddResponse
        {
            public XferTrnAddRs XferTrnAddRs { get; set; }
        }

        public class XferTrnAddRs
        {
            public TrnIdentifier TrnIdentifier { get; set; }
        }

        public class TrnIdentifier
        {
            public string TrnId { get; set; }
        }

    

       
    }

}