﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.CustomModel
{
   

    public class KendoGrid
    {
        public int skip { get; set; }
        public int take { get; set; }
        public int pagesize { get; set; }
        public int page { get; set; }
        public string Search { get; set; }
        public int? BranchId { get; set; }
        public int? StatusId { get; set; }
        public int GroupId { get; set; }
             public int messageid { get; set; }     
        public string FromDate { get; set; }
        public string ToDate { get; set; }




    }
    public class PagedData
    {
        public int Total { get; set; }
        public object Result { get; set; }
    }

}