﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.CustomModel
{
    public class SettingList
    {
        public int Id { get; set; }
        public string VehicleType { get; set; }
        public int VehicleTypeId { get; set; }
        public decimal RefundableSecurityDeposit { get; set; }
        public decimal FastagFee { get; set; }
        public decimal MinimumBalanceWalletDeposit { get; set; }
        public decimal Others { get; set; }     
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }


    }

    public class VehicleTypeList
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class VehicleTypeDropDown
    {
        public int Id { get; set; }
        public string Name { get; set; }
       
    }
}