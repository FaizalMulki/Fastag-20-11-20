﻿using MySql.Data.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.DAL
{

    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class MyDBContext : DbContext
    {

     
        public DbSet<Setting> Setting { get; set; }
        public DbSet <Registration> Registration { get; set; }
        public DbSet<VehicleType> VehicleType { get; set; }
        public DbSet<Document> Document { get; set; }
        public DbSet<Recharge> Recharge { get; set; }
       
        public MyDBContext()
      : base()
    {

        }

        // Constructor to use on a DbConnection that is already opened
        public MyDBContext(DbConnection existingConnection, bool contextOwnsConnection)
      : base(existingConnection, contextOwnsConnection)
    {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);           
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }

   public class Setting
    {
     
        public int Id { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public int VehicleTypeId { get; set; }       
        public decimal RefundableSecurityDeposit { get; set; }
        public decimal FastagFee { get; set; }
        public decimal MinimumBalanceWalletDeposit { get; set; }
        public decimal Others { get; set; }
        public bool IsDeleted { get; set; }
         public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }


    public class VehicleType
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Code { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public class Document 
    {
       
        public int Id { get; set; }
        public int ReferenceId { get; set; }
        public string DocumentName { get; set; }
        public string DocumentType { get; set; }
        public string Extension { get; set; }
        public byte[] Documents { get; set; }
        public string DocumentPath { get; set; }
        public bool IsVehicle { get; set; }
        public bool IsPAN { get; set; }
        public string IdType { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }

    }

    public class Registration
    {

        public int Id { get; set; }
        public string ReferenceNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string DeliveryAddress { get; set; }
        public int VehicleTypeId { get; set; }
        public string VehicleRegNo { get; set; }
        public decimal SecurityDeposit { get; set; }
        public decimal FastagFee { get; set; }
        public decimal MinimumBalanceDeposit { get; set; }
        public decimal TotalPayable { get; set; }
        public decimal Others { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string PaymentType { get; set; }
        public string FromAccountNumber { get; set; }
        public string ToAccountNumber { get; set; }
        public string BranchCode { get; set; }
        public string FatherName { get; set; }
        public DateTime? DOB { get; set; }
        public string FinacleTransNumber { get; set; }
        public int StatusId { get; set; }
        public string ApprovedBy { get; set; }
        public string ApproverBranchCode { get; set; }
        public DateTime? ApprovedDate { get; set; }

    }


    public class Recharge
    {

        public int Id { get; set; }
        public string VehicleRegNo { get; set; }
        public decimal Amount { get; set; }
        public string TransactionId { get; set; }
        public string WLTransactionId { get; set; }
        public string FinacleReference { get; set; }
        public string ResponseCode { get; set; }
        public string ResponseMsg { get; set; }
        public bool AmountDeducted { get; set; }
        public bool RechargeSuccess { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string BranchCode { get; set; }
        public string PaymentType { get; set; }
        public string FromAccountNumber { get; set; }
        public string ToAccountNumber { get; set; }
        public int StatusId { get; set; }
        public string RechargedBy { get; set; }
        public DateTime? RechargedDate { get; set; }
        public bool IsDeleted { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string txnDateTime { get; set; }

    }

}
