﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OrchestratorAsset.Web.CustomModel;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Xml.Serialization;
using Vigilance.Web;


namespace OrchestratorAsset.Web.Controllers
{
    [NoDirectAccessAttribute]
    public class WalletRechargeController : Controller
    {
        // GET: WalletRecharge
        public ActionResult Recharge()
        {
            string actTransNumber = ConfigurationManager.AppSettings["ActTransNumber"];
            string cashTransNumber = ConfigurationManager.AppSettings["CashTransNumber"];
            string BranchCode = Session["BranchCode"].ToString();
            ViewBag.ActNumber = BranchCode.ToString() + actTransNumber.ToString();
            ViewBag.CashNumber = BranchCode.ToString() + cashTransNumber.ToString();
            return View();
        }

        public ActionResult List()
        {
            return View();
        }

        public ActionResult Edit(int Id)
        {
            return View();
        }

        public ActionResult ApproveRechargeList()
        {
            return View();
        }


        public object GetAllItems(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    var branchCode = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        branchCode = Session["BranchCode"].ToString();

                    }
                    else
                    {

                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                    }

                    DateTime fromDt = DateTime.ParseExact(grid.FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromStr = fromDt.ToString("yyyy-MM-dd");
                    DateTime toDt = DateTime.ParseExact(grid.ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string toStr = toDt.ToString("yyyy-MM-dd");

                    MySqlCommand cmd = new MySqlCommand("GetAllRecharges", connection);
                    cmd.Parameters.AddWithValue("BranchCode", branchCode);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("FromDate", fromStr);
                    cmd.Parameters.AddWithValue("ToDate", toStr);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RechargeModel> groups = new List<RechargeModel>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RechargeModel>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }


        [HttpPost]
        public string DeleteRecharge(WalletRecharge model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {
                        var checkStatus = context.Recharge.Where(x => x.Id == model.Id && x.StatusId == 2).Count();
                        if (checkStatus > 0)
                        {
                            return "dependency";
                        }
                        else
                        {
                            var record = context.Recharge.Where(x => x.Id == model.Id).FirstOrDefault().IsDeleted = true;
                            context.SaveChanges();
                            return "success";
                        }
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;

                    }
                }
            }
            return "error";
        }




        public ActionResult GetDetails(int Id)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    MySqlCommand cmd = new MySqlCommand("GetRechargeById", connection);
                    cmd.Parameters.AddWithValue("Id", Id);
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RechargeModel> groups = new List<RechargeModel>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RechargeModel>(dt);

                    }

                    return Json(groups, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }


        public object GetAllPendingRechargeItems(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    var branchCode = "";
                    var fullName = "";
                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {


                        branchCode = Session["BranchCode"].ToString();
                        fullName = Session["FullName"].ToString();

                    }
                    else
                    {

                        branchCode = ConfigurationManager.AppSettings["BranchCode"];
                        fullName = Session["FullName"].ToString();
                    }

                    DateTime fromDt = DateTime.ParseExact(grid.FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string fromStr = fromDt.ToString("yyyy-MM-dd");
                    DateTime toDt = DateTime.ParseExact(grid.ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    string toStr = toDt.ToString("yyyy-MM-dd");

                    MySqlCommand cmd = new MySqlCommand("GetAllRechargesForApproval", connection);
                    cmd.Parameters.AddWithValue("CreatedBy", fullName);
                    cmd.Parameters.AddWithValue("BranchCode", branchCode);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("FromDate", fromStr);
                    cmd.Parameters.AddWithValue("ToDate", toStr);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<RechargeModel> groups = new List<RechargeModel>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<RechargeModel>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }


        public string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }

        public string GenerateAlphaNumericString()
        {
            var date = DateTime.Now;
            string data = "KBL" + date.Day.ToString("00") + date.Month.ToString("00") + date.Year + date.Hour + date.Minute + date.Second;
            return data;
        }


        [HttpPost]
        public object SaveRecharge(WalletRecharge recharge)
        {
            var exceptionMessage = "";

            var transId = GenerateAlphaNumericString();
            recharge.ReferenceNumber = transId;


            try
            {


                using (MySqlConnection connection = new MySqlConnection(Connection()))
                {
                    using (MyDBContext context = new MyDBContext(connection, false))
                    {

                        var fullName = "";
                        var branchCode = "";
                        var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                        if (loginFromAD.ToLower().Trim() == "yes")
                        {

                            fullName = Session["FullName"].ToString();
                            branchCode = Session["BranchCode"].ToString();

                        }
                        else
                        {
                            fullName = ConfigurationManager.AppSettings["DummyUserName"];
                            branchCode = ConfigurationManager.AppSettings["BranchCode"];
                        }




                        var checkBal = CheckBalance(recharge.FromAccountNumber.Trim(), transId);

                        if (checkBal.Split('-')[0].ToLower() == "true")
                        {
                            decimal balAmt = Convert.ToDecimal(checkBal.Split('-')[1]);

                            if (balAmt >= Convert.ToDecimal(recharge.Amount))
                            {

                                try
                                {

                                    Recharge rech = new Recharge();
                                    rech.VehicleRegNo = recharge.VehicleRegNo;
                                    rech.Amount = Convert.ToInt32(recharge.Amount);
                                    rech.FinacleReference = "";
                                    rech.TransactionId = transId;
                                    rech.PaymentType = recharge.PaymentType;
                                    rech.FromAccountNumber = recharge.FromAccountNumber;
                                    rech.ToAccountNumber = recharge.ToAccountNumber;
                                    rech.WLTransactionId = "";
                                    rech.ResponseCode = "";
                                    rech.ResponseMsg = "";
                                    rech.CreatedBy = fullName;
                                    rech.CreatedDate = DateTime.Now;
                                    rech.AmountDeducted = false;
                                    rech.RechargeSuccess = false;
                                    rech.BranchCode = branchCode;
                                    rech.IsDeleted = false;
                                    rech.UpdatedBy = "";
                                    rech.UpdatedDate = null;
                                    rech.RechargedBy = "";
                                    rech.RechargedDate = null;
                                    rech.StatusId = (int)Status.Pending;
                                    context.Recharge.Add(rech);
                                    context.SaveChanges();
                                    return "success" + "-";
                                }

                                catch (Exception e)
                                {
                                    exceptionMessage = e.Message;
                                    return "failure" + "-" + "exception" + "-" + exceptionMessage;

                                }

                            }
                            else
                            {
                                return "failure" + "-" + "insuffiecient";
                            }

                        }

                       
                        else
                        {
                            return "failure" + "-" + "exceptionBal";
                        }




                    }
                }


            }
            catch (Exception e)
            {
                exceptionMessage = e.Message;
            }

            return "failure" + "-" + "exception" + "-" + exceptionMessage;

        }


        [HttpPost]
        public object UpdateRecharge(WalletRecharge recharge)
        {
            var exceptionMessage = "";
            try
            {


                using (MySqlConnection connection = new MySqlConnection(Connection()))
                {
                    using (MyDBContext context = new MyDBContext(connection, false))
                    {


                        var transId = GenerateAlphaNumericString();
                        recharge.ReferenceNumber = transId;

                        var fullName = "";
                        var branchCode = "";
                        var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                        if (loginFromAD.ToLower().Trim() == "yes")
                        {

                            fullName = Session["FullName"].ToString();
                            branchCode = Session["BranchCode"].ToString();

                        }
                        else
                        {
                            fullName = ConfigurationManager.AppSettings["DummyUserName"];
                            branchCode = ConfigurationManager.AppSettings["BranchCode"];
                        }
                        try
                        {
                            Recharge rec = context.Recharge
                             .Where(p => p.Id == recharge.Id).FirstOrDefault();



                            var checkBal = CheckBalance(recharge.FromAccountNumber.Trim(), transId);

                            if (checkBal.Split('-')[0].ToLower() == "true")
                            {
                                decimal balAmt = Convert.ToDecimal(checkBal.Split('-')[1]);

                                if (balAmt >= Convert.ToDecimal(recharge.Amount))
                                {

                                    try
                                    {
                                        if (rec != null)
                                        {

                                            rec.VehicleRegNo = recharge.VehicleRegNo;
                                            rec.Amount = Convert.ToInt32(recharge.Amount);
                                            rec.PaymentType = recharge.PaymentType;
                                            rec.FromAccountNumber = recharge.FromAccountNumber;
                                            rec.ToAccountNumber = recharge.ToAccountNumber;
                                            rec.BranchCode = branchCode;
                                            rec.IsDeleted = false;
                                            rec.UpdatedBy = fullName;
                                            rec.UpdatedDate = DateTime.Now;
                                            rec.StatusId = (int)Status.Pending;
                                            context.SaveChanges();
                                            return "success" + "-";
                                        }
                                    }

                                    catch (Exception e)
                                    {
                                        exceptionMessage = e.Message;
                                        return "failure" + "-" + "exception" + "-" + exceptionMessage;

                                    }

                                }
                                else
                                {
                                    return "failure" + "-" + "insuffiecient";
                                }

                            }

                          
                            else
                            {
                                return "failure" + "-" + "exceptionBal";
                            }


                        }
                        catch (Exception e)
                        {
                            exceptionMessage = e.Message;
                            return "failure" + "-" + "exception" + "-" + exceptionMessage;

                        }


                    }
                }
            }


            catch (Exception e)
            {
                exceptionMessage = e.Message;
            }

            return "failure" + "-" + "exception" + "-" + exceptionMessage;


        }



        [HttpPost]
        public async Task<String> RechargeWallet(WalletRecharge recharge)
        {
            var exceptionMessage = "";
            bool amountDeducted = false;
            bool isRecharged = false;
            var transId = GenerateAlphaNumericString();
            recharge.ReferenceNumber = transId;
            var Id = 0;

            try
            {


                using (MySqlConnection connection = new MySqlConnection(Connection()))
                {
                    using (MyDBContext context = new MyDBContext(connection, false))
                    {

                        var fullName = "";
                        var branchCode = "";
                        var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                        if (loginFromAD.ToLower().Trim() == "yes")
                        {

                            fullName = Session["FullName"].ToString();
                            branchCode = Session["BranchCode"].ToString();

                        }
                        else
                        {
                            fullName = ConfigurationManager.AppSettings["DummyUserName"];
                            branchCode = ConfigurationManager.AppSettings["BranchCode"];
                        }




                        var checkBal = CheckBalance(recharge.FromAccountNumber.Trim(), transId);

                        if (checkBal.Split('-')[0].ToLower() == "true")
                        {
                            decimal balAmt = Convert.ToDecimal(checkBal.Split('-')[1]);

                            if (balAmt >= Convert.ToDecimal(recharge.Amount))
                            {

                                var result = DoTransaction(recharge);
                                if (result.Split('-')[0].ToLower() == "true")
                                {

                                    try
                                    {
                                        amountDeducted = true;
                                        RequestClass obj = new RequestClass();
                                        obj.flag = "RECH";
                                        obj.etcCustId = "";
                                        obj.vrn = recharge.VehicleRegNo.Trim().ToUpper();
                                        obj.rechargeTxnid = transId;
                                        obj.rechargeAmt = recharge.Amount;
                                        string json = JsonConvert.SerializeObject(obj);
                                        var encryptedMessage = encryptMessage(json);

                                        string rechargeURL = ConfigurationManager.AppSettings["RechargeURL"].ToString();

                                        string MyProxyHostString = ConfigurationManager.AppSettings["ProxyURL"].ToString();
                                        int MyProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);

                                        ServicePointManager.ServerCertificateValidationCallback +=
                                            delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };

                                        var request = (HttpWebRequest)WebRequest.Create(rechargeURL);
                                        request.Proxy = new WebProxy(MyProxyHostString, MyProxyPort);
                                        request.Method = "POST";
                                        request.ContentType = "application/json";
                                        request.Accept = "application/json";

                                        APIFormat req = new APIFormat();
                                        req.reqdata = encryptedMessage;
                                        req.msgid = "0";
                                        string jsonReq = JsonConvert.SerializeObject(req);

                                        using (var streamwriter = new StreamWriter(request.GetRequestStream()))
                                        {
                                            streamwriter.Write(jsonReq);
                                        }

                                        var response = (HttpWebResponse)request.GetResponse();
                                        Stream stream = response.GetResponseStream();
                                        StreamReader sr = new StreamReader(stream);
                                        string s = sr.ReadToEnd();

                                        string decrypt = decryptMessage(s);

                                        var resp = JsonConvert.DeserializeObject<RechargeWalletResponse>(decrypt);

                                        if (resp.resCode == "00")

                                        {

                                            Recharge rec = context.Recharge.Where(p => p.Id == recharge.Id).FirstOrDefault();

                                            if (rec != null)
                                            {

                                                isRecharged = true;
                                                rec.RechargedBy = fullName;
                                                rec.RechargedDate = DateTime.Now;
                                                rec.RechargeSuccess = isRecharged;
                                                rec.AmountDeducted = amountDeducted;
                                                rec.WLTransactionId = resp.wltxnId;
                                                rec.TransactionId = transId;
                                                rec.ResponseCode = resp.resCode;
                                                rec.ResponseMsg = resp.resMsg;
                                                rec.txnDateTime = resp.txnDateTime;
                                                rec.FinacleReference= result.Split('-')[1];
                                                rec.StatusId = (int)Status.Approved;
                                                context.SaveChanges();


                                                
                                            }

                                            
                                            return "success" + "-" + resp.resMsg;
                                        }

                                        else
                                        {
                                          

                                            if (!isRecharged && amountDeducted)
                                            {
                                                ReverseTransaction(recharge);
                                                Recharge rec = context.Recharge.Where(p => p.Id == recharge.Id).FirstOrDefault();
                                                Id = rec.Id;
                                                if (Id != 0)
                                                {

                                                    rec.RechargeSuccess = false;
                                                    rec.AmountDeducted = false;
                                                    rec.StatusId = (int)Status.Pending;
                                                    context.SaveChanges();
                                                }
                                                return "failureRecharge" + "-" + resp.resMsg;
                                            }

                                        }




                                    }

                                    catch (Exception e)
                                    {
                                        var k = e.Message;
                                        if (!isRecharged && amountDeducted)
                                        {
                                            ReverseTransaction(recharge);
                                            Recharge rec = context.Recharge.Where(p => p.Id == recharge.Id).FirstOrDefault();
                                            Id = rec.Id;
                                            if (Id != 0)
                                            {

                                                rec.RechargeSuccess = false;
                                                rec.AmountDeducted = false;
                                                rec.StatusId = (int)Status.Pending;
                                                context.SaveChanges();
                                            }

                                        }
                                    }





                                }

                                else if (result.Split('-')[0].ToLower() == "false" && result.Split('-')[1] == "ExceptionOccured")
                                {
                                    return "failure" + "-" + "exceptionTrans";

                                }
                                else
                                {
                                    return "failure" + "-" +""+"-"+ result.Split('-')[1];

                                }
                            }
                            else
                            {

                            
                            return "failure" + "-" + "insuffiecient";
                            }
                           

                        }

                        else if (checkBal.Split('-')[0].ToLower() == "false" )
                        {
                            return "failureBal" + "-" + checkBal.Split('-')[1];
                        }
                        else
                        {
                            return "failure" + "-" + "exceptionBal";
                        }




                    }
                }


            }
            catch (Exception e)
            {
                exceptionMessage = e.Message;
            }

            return "failure" + "-" + "exception" + "-" + exceptionMessage;

        }


        public string CheckBalance(string AccountNumber, string ReferenceNumber)
        {
            HTTPRequest req = new HTTPRequest();
            bool success = false;
            var res = "";
            decimal amount = 0;

            string Url = ConfigurationManager.AppSettings["FinacleURL"].ToString();

            var tod = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
            string requestXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml BalInq.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>" + "Req_" + ReferenceNumber + " </RequestUUID>\r\n<ServiceRequestId>BalInq</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>" + tod + "</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<BalInqRq>\r\n<AcctId>\r\n<AcctId>" + AccountNumber + "</AcctId>\r\n</AcctId>\r\n</BalInqRq>\r\n</Body>\r\n</FIXML>\r\n";

            var response = req.postXMLData(Url, requestXml);
            using (TextReader reader = new StringReader(response))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(BalanceCheck.FIXML));
                    var result = (BalanceCheck.FIXML)serializer.Deserialize(reader);

                    if (result.Header.ResponseHeader.HostTransaction.Status.ToLower() == "success")
                    {
                        amount = result.Body.BalInqResponse.BalInqRs.AcctBalItems.First().BalAmt.amountValue;
                        success = true;
                        res = success + "-" + amount;
                    }
                    else
                    {
                        success = false;
                        res = success + "-" + result.Body.Error.FIBusinessException.ErrorDetail.ErrorDesc;
                    }
                    return res;

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }



            }
            success = false;
            res = success + "-" + "ExceptionOccured";
            return res;
        }




        [HttpPost]
        public object CheckNumberIsValid(VehicleParams Vehicle)
        {

            var res = VehicleValidation(Vehicle.vrn);
            return Json(res, JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public object CheckFastagBalance(VehicleParams Vehicle)
        {
            var res = BalanceCheck(Vehicle.vrn);
            return Json(res, JsonRequestBehavior.AllowGet);
        }


        public async Task<VehicleInfo> VehicleValidation(string vrn)
        {


            RegisterClass obj = new RegisterClass();
            obj.flag = "VI";
            obj.etcCustId = "";
            obj.vrn = vrn.Trim().ToUpper();


            string json = JsonConvert.SerializeObject(obj);
            var encryptedMessage = encryptMessage(json);



            string apiURL = ConfigurationManager.AppSettings["DetailsURL"].ToString();

            string MyProxyHostString = ConfigurationManager.AppSettings["ProxyURL"].ToString();
            int MyProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);

            //Bypass SSL Verification
            ServicePointManager.ServerCertificateValidationCallback +=
                delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };

            var request = (HttpWebRequest)WebRequest.Create(apiURL);
            request.Proxy = new WebProxy(MyProxyHostString, MyProxyPort);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Accept = "application/json";

            APIFormat req = new APIFormat();
            req.reqdata = encryptedMessage;
            req.msgid = "0";
            string jsonReq = JsonConvert.SerializeObject(req);

            using (var streamwriter = new StreamWriter(request.GetRequestStream()))
            {
                streamwriter.Write(jsonReq);
            }

            var response = (HttpWebResponse)request.GetResponse();
            Stream stream = response.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string s = sr.ReadToEnd();

            string decrypt = decryptMessage(s);

            var result = JsonConvert.DeserializeObject<VehicleInfo>(decrypt);

            return result;

        }



        public async Task<CustomerInfo> BalanceCheck(string vrn)
        {


            RegisterClass obj = new RegisterClass();
            obj.flag = "CI";
            obj.etcCustId = "";
            obj.vrn = vrn.Trim().ToUpper();
            try
            {

                string json = JsonConvert.SerializeObject(obj);
                var encryptedMessage = encryptMessage(json);



                string apiURL = ConfigurationManager.AppSettings["DetailsURL"].ToString();

                string MyProxyHostString = ConfigurationManager.AppSettings["ProxyURL"].ToString();
                int MyProxyPort = Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]);

                //Bypass SSL Verification
                ServicePointManager.ServerCertificateValidationCallback +=
                    delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };

                var request = (HttpWebRequest)WebRequest.Create(apiURL);
                request.Proxy = new WebProxy(MyProxyHostString, MyProxyPort);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";

                APIFormat req = new APIFormat();
                req.reqdata = encryptedMessage;
                req.msgid = "0";
                string jsonReq = JsonConvert.SerializeObject(req);

                using (var streamwriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamwriter.Write(jsonReq);
                }

                var response = (HttpWebResponse)request.GetResponse();
                Stream stream = response.GetResponseStream();
                StreamReader sr = new StreamReader(stream);
                string s = sr.ReadToEnd();

                string decrypt = decryptMessage(s);
                var result = JsonConvert.DeserializeObject<CustomerInfo>(decrypt);
                return result;
            }
            catch (Exception e)
            {
                var k = e.Message;
            }


            return null;

        }





        public string generateKey(String password, byte[] saltBytes)
        {

            int iterations = 100;
            var rfc2898 =
            new System.Security.Cryptography.Rfc2898DeriveBytes(password, saltBytes, iterations);
            byte[] key = rfc2898.GetBytes(16);
            String keyB64 = Convert.ToBase64String(key);
            return keyB64;
        }

        public static byte[] hexStringToByteArray(string hexString)
        {



            byte[] data = new byte[hexString.Length / 2];
            for (int index = 0; index < data.Length; index++)
            {
                string byteValue = hexString.Substring(index * 2, 2);
                data[index] = byte.Parse(byteValue, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            }

            return data;


        }


        static Random random = new Random();
        public static string GetRandomHexNumber(int digits)
        {
            byte[] buffer = new byte[digits / 2];
            random.NextBytes(buffer);
            string result = String.Concat(buffer.Select(x => x.ToString("X2")).ToArray());
            if (digits % 2 == 0)
                return result;
            return result + random.Next(16).ToString("X");
        }


        public string encryptMessage(string message)
        {

            String combineData = "";
            try
            {


                string passphrase = ConfigurationManager.AppSettings["EncryptionDecryptionKey"].ToString();
                string saltHex = GetRandomHexNumber(32);
                string ivHex = GetRandomHexNumber(32);
                byte[] salt = hexStringToByteArray(saltHex);
                byte[] iv = hexStringToByteArray(ivHex);

                string sKey = generateKey(passphrase, salt);
                byte[] keyBytes = System.Convert.FromBase64String(sKey);
                AesManaged aesCipher = new AesManaged();

                aesCipher.KeySize = 128;
                aesCipher.BlockSize = 128;
                aesCipher.Mode = CipherMode.CBC;
                aesCipher.Padding = PaddingMode.PKCS7;
                aesCipher.Key = keyBytes;

                byte[] b = System.Text.Encoding.UTF8.GetBytes(message);
                ICryptoTransform encryptTransform = aesCipher.CreateEncryptor(keyBytes, iv);
                byte[] ctext = encryptTransform.TransformFinalBlock(b, 0, b.Length);

                var plainTextBytes = System.Convert.ToBase64String(ctext);

                combineData = saltHex + " " + ivHex + " " + plainTextBytes;

            }
            catch (Exception e)
            {

            }
            combineData = combineData.Replace("\n", "").Replace("\t", "").Replace("\r", "");
            return combineData;
        }


        public string decryptMessage(string str)
        {

            string myKey = ConfigurationManager.AppSettings["EncryptionDecryptionKey"].ToString();
            string decrypted = null;
            try
            {
                if ((str != null) && (str.Contains(' ')))
                {
                    string salt = str.Split(' ')[0];
                    string iv = str.Split(' ')[1];
                    string encryptedText = str.Split(' ')[2];

                    decrypted = Decrypt(salt, iv, myKey, encryptedText);
                    return decrypted;
                }
                else
                {
                    decrypted = str;
                    return decrypted;
                }
            }
            catch (Exception e)
            {

            }

            return decrypted;

        }


        public string Decrypt(string salt, string iv, string passphrase, string EncryptedText)
        {
            string decryptedValue = null;
            try
            {
                byte[] saltBytes = hexStringToByteArray(salt);

                string sKey = generateKey(passphrase, saltBytes);
                byte[] ivBytes = hexStringToByteArray(iv);


                byte[] keyBytes = System.Convert.FromBase64String(sKey);


                AesManaged aesCipher = new AesManaged();
                aesCipher.IV = ivBytes;
                aesCipher.KeySize = 128;
                aesCipher.BlockSize = 128;
                aesCipher.Mode = CipherMode.CBC;
                aesCipher.Padding = PaddingMode.PKCS7;
                byte[] b = System.Convert.FromBase64String(EncryptedText);
                ICryptoTransform decryptTransform = aesCipher.CreateDecryptor(keyBytes, ivBytes);
                byte[] plainText = decryptTransform.TransformFinalBlock(b, 0, b.Length);

                var res = System.Text.Encoding.UTF8.GetString(plainText);
                return res;
            }
            catch (Exception e)
            {
                var k = e.Message;
            }
            return "";
        }



        public string DoTransaction(WalletRecharge model)
        {
            HTTPRequest req = new HTTPRequest();
            bool success = false;
            var res = "";
            var requestUUID = GenerateAlphaNumericString();
            string Url = ConfigurationManager.AppSettings["FinacleURL"].ToString();
            var tod = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
            //var tod = "2020-06-11T13:16:45.302 + 05:30";
            // string requestData = "<?xml version=1.0 encoding=UTF-8?><FIXML xsi:schemaLocation=http://www.finacle.com/fixml BalInq.xsd xmlns= http://www.finacle.com/fixml xmlns:xsi=w3.org/2001/XMLSchema-instance><Header><RequestHeader><MessageKey><RequestUUID>Req_1560515797477</RequestUUID><ServiceRequestId>BalInq</ServiceRequestId><ServiceRequestVersion>10.2</ServiceRequestVersion><ChannelId>COR</ChannelId><LanguageId></LanguageId></MessageKey><RequestMessageInfo><BankId>01</BankId><TimeZone></TimeZone><EntityId></EntityId><EntityType></EntityType><ArmCorrelationId></ArmCorrelationId><MessageDateTime>2019-05-14T15:36:37.477</MessageDateTime></RequestMessageInfo><Security><Token><PasswordToken><UserId></UserId><Password></Password></PasswordToken></Token><FICertToken></FICertToken><RealUserLoginSessionId></RealUserLoginSessionId><RealUser></RealUser><RealUserPwd></RealUserPwd><SSOTransferToken></SSOTransferToken></Security></RequestHeader></Header><Body><BalInqRq><AcctId><AcctId>0022500100003001</AcctId></AcctId></BalInqRq></Body> </ FIXML >";
            //string newRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml XferTrnAdd.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" www.w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>Req_1560515797477</RequestUUID>\r\n<ServiceRequestId>XferTrnAdd</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>2019-05-14T15:36:37.477</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<XferTrnAddRq>\r\n<XferTrnHdr>\r\n<TrnType>T</TrnType>\r\n<TrnSubType>CI</TrnSubType>\r\n</XferTrnHdr>\r\n<XferTrnDetail>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>4732500101964301</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>D</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>2</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>To Raju</TrnParticulars>\r\n<PartTrnRmks>7894562587415634</PartTrnRmks>\r\n<SerialNum>1</SerialNum>\r\n<ValueDt>2019-07-11T00:00:00.000</ValueDt>\r\n</PartTrnRec>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>4362500100484501</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>C</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>2</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>By Ganesh</TrnParticulars>\r\n<PartTrnRmks>7894562587415634</PartTrnRmks>\r\n<SerialNum>2</SerialNum>\r\n<ValueDt>2019-07-11T00:00:00.000</ValueDt>\r\n</PartTrnRec>\r\n</XferTrnDetail>\r\n</XferTrnAddRq>\r\n</Body>\r\n</FIXML>\r\n\r\n";
            string newRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml XferTrnAdd.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" www.w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>Req_"+ requestUUID + "</RequestUUID>\r\n<ServiceRequestId>XferTrnAdd</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>" + tod + "</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<XferTrnAddRq>\r\n<XferTrnHdr>\r\n<TrnType>T</TrnType>\r\n<TrnSubType>CI</TrnSubType>\r\n</XferTrnHdr>\r\n<XferTrnDetail>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>" + model.FromAccountNumber.Trim() + "</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>D</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>" + model.Amount + "</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>" + "Fastag-Reference Number-" + model.ReferenceNumber + "</TrnParticulars>\r\n<PartTrnRmks></PartTrnRmks>\r\n<SerialNum>1</SerialNum>\r\n<ValueDt>" + tod + "</ValueDt>\r\n</PartTrnRec>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>" + model.ToAccountNumber.Trim() + "</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>C</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>" + model.Amount + "</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>" + "Fastag - Reference Number - " + model.ReferenceNumber + " </TrnParticulars>\r\n<PartTrnRmks></PartTrnRmks>\r\n<SerialNum>2</SerialNum>\r\n<ValueDt>" + tod + "</ValueDt>\r\n</PartTrnRec>\r\n</XferTrnDetail>\r\n</XferTrnAddRq>\r\n</Body>\r\n</FIXML>\r\n\r\n";

            var response = req.postXMLData(Url, newRequest);

            using (TextReader reader = new StringReader(response))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(CreditDebitTransaction.FIXML));
                    var result = (CreditDebitTransaction.FIXML)serializer.Deserialize(reader);
                    if (result.Header.ResponseHeader.HostTransaction.Status.ToLower() == "success")
                    {
                        var transId = result.Body.XferTrnAddResponse.XferTrnAddRs.TrnIdentifier.TrnId;
                        success = true;
                        res = success + "-" + transId;
                        return res;
                    }
                    else
                    {



                        var error = result.Body.Error.FIBusinessException.ErrorDetail.First().ErrorDesc;

                        success = false;
                        res = success + "-" + error;
                        return res;
                    }



                }
                catch (Exception e)
                {
                    var k = e.Message;
                }

                res = success + "-" + "ExceptionOccured";
                return res;

            }
        }


        public string ReverseTransaction(WalletRecharge model)
        {
            HTTPRequest req = new HTTPRequest();
            bool success = false;
            var res = "";
            var requestUUID = GenerateAlphaNumericString();
            string Url = ConfigurationManager.AppSettings["FinacleURL"].ToString();
            var tod = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK");
           // var tod = "2020-06-11T13:16:45.302 + 05:30";
            // string requestData = "<?xml version=1.0 encoding=UTF-8?><FIXML xsi:schemaLocation=http://www.finacle.com/fixml BalInq.xsd xmlns= http://www.finacle.com/fixml xmlns:xsi=w3.org/2001/XMLSchema-instance><Header><RequestHeader><MessageKey><RequestUUID>Req_1560515797477</RequestUUID><ServiceRequestId>BalInq</ServiceRequestId><ServiceRequestVersion>10.2</ServiceRequestVersion><ChannelId>COR</ChannelId><LanguageId></LanguageId></MessageKey><RequestMessageInfo><BankId>01</BankId><TimeZone></TimeZone><EntityId></EntityId><EntityType></EntityType><ArmCorrelationId></ArmCorrelationId><MessageDateTime>2019-05-14T15:36:37.477</MessageDateTime></RequestMessageInfo><Security><Token><PasswordToken><UserId></UserId><Password></Password></PasswordToken></Token><FICertToken></FICertToken><RealUserLoginSessionId></RealUserLoginSessionId><RealUser></RealUser><RealUserPwd></RealUserPwd><SSOTransferToken></SSOTransferToken></Security></RequestHeader></Header><Body><BalInqRq><AcctId><AcctId>0022500100003001</AcctId></AcctId></BalInqRq></Body> </ FIXML >";
            //string newRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml XferTrnAdd.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" www.w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>Req_1560515797477</RequestUUID>\r\n<ServiceRequestId>XferTrnAdd</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>2019-05-14T15:36:37.477</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<XferTrnAddRq>\r\n<XferTrnHdr>\r\n<TrnType>T</TrnType>\r\n<TrnSubType>CI</TrnSubType>\r\n</XferTrnHdr>\r\n<XferTrnDetail>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>4732500101964301</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>D</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>2</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>To Raju</TrnParticulars>\r\n<PartTrnRmks>7894562587415634</PartTrnRmks>\r\n<SerialNum>1</SerialNum>\r\n<ValueDt>2019-07-11T00:00:00.000</ValueDt>\r\n</PartTrnRec>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>4362500100484501</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>C</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>2</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>By Ganesh</TrnParticulars>\r\n<PartTrnRmks>7894562587415634</PartTrnRmks>\r\n<SerialNum>2</SerialNum>\r\n<ValueDt>2019-07-11T00:00:00.000</ValueDt>\r\n</PartTrnRec>\r\n</XferTrnDetail>\r\n</XferTrnAddRq>\r\n</Body>\r\n</FIXML>\r\n\r\n";
            string newRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<FIXML xsi:schemaLocation=\" http://www.finacle.com/fixml XferTrnAdd.xsd\" xmlns=\" http://www.finacle.com/fixml\" xmlns:xsi=\" www.w3.org/2001/XMLSchema-instance\">\r\n<Header>\r\n<RequestHeader>\r\n<MessageKey>\r\n<RequestUUID>Req_"+ requestUUID + "</RequestUUID>\r\n<ServiceRequestId>XferTrnAdd</ServiceRequestId>\r\n<ServiceRequestVersion>10.2</ServiceRequestVersion>\r\n<ChannelId>COR</ChannelId>\r\n<LanguageId></LanguageId>\r\n</MessageKey>\r\n<RequestMessageInfo>\r\n<BankId>01</BankId>\r\n<TimeZone></TimeZone>\r\n<EntityId></EntityId>\r\n<EntityType></EntityType>\r\n<ArmCorrelationId></ArmCorrelationId>\r\n<MessageDateTime>" + tod + "</MessageDateTime>\r\n</RequestMessageInfo>\r\n<Security>\r\n<Token>\r\n<PasswordToken>\r\n<UserId></UserId>\r\n<Password></Password>\r\n</PasswordToken>\r\n</Token>\r\n<FICertToken></FICertToken>\r\n<RealUserLoginSessionId></RealUserLoginSessionId>\r\n<RealUser></RealUser>\r\n<RealUserPwd></RealUserPwd>\r\n<SSOTransferToken></SSOTransferToken>\r\n</Security>\r\n</RequestHeader>\r\n</Header>\r\n<Body>\r\n<XferTrnAddRq>\r\n<XferTrnHdr>\r\n<TrnType>T</TrnType>\r\n<TrnSubType>CI</TrnSubType>\r\n</XferTrnHdr>\r\n<XferTrnDetail>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>" + model.ToAccountNumber.Trim() + "</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>D</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>" + model.Amount + "</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>" + "Fastag-Wallet Recharge Reversal-" + model.ReferenceNumber + "</TrnParticulars>\r\n<PartTrnRmks></PartTrnRmks>\r\n<SerialNum>1</SerialNum>\r\n<ValueDt>" + tod + "</ValueDt>\r\n</PartTrnRec>\r\n<PartTrnRec>\r\n<AcctId>\r\n<AcctId>" + model.FromAccountNumber.Trim() + "</AcctId>\r\n</AcctId>\r\n<CreditDebitFlg>C</CreditDebitFlg>\r\n<TrnAmt>\r\n<amountValue>" + model.Amount + "</amountValue>\r\n<currencyCode>INR</currencyCode>\r\n</TrnAmt>\r\n<TrnParticulars>" + "Fastag - Wallet Recharge - " + model.ReferenceNumber + " </TrnParticulars>\r\n<PartTrnRmks></PartTrnRmks>\r\n<SerialNum>2</SerialNum>\r\n<ValueDt>" + tod + "</ValueDt>\r\n</PartTrnRec>\r\n</XferTrnDetail>\r\n</XferTrnAddRq>\r\n</Body>\r\n</FIXML>\r\n\r\n";

            var response = req.postXMLData(Url, newRequest);

            using (TextReader reader = new StringReader(response))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(CreditDebitTransaction.FIXML));
                    var result = (CreditDebitTransaction.FIXML)serializer.Deserialize(reader);
                    if (result.Header.ResponseHeader.HostTransaction.Status.ToLower() == "success")
                    {
                        var transId = result.Body.XferTrnAddResponse.XferTrnAddRs.TrnIdentifier.TrnId;
                        success = true;
                        res = success + "-" + transId;
                        return res;
                    }
                    else
                    {



                        var error = result.Body.Error.FIBusinessException.ErrorDetail.First().ErrorDesc;

                        success = false;
                        res = success + "-" + error;
                        return res;
                    }



                }
                catch (Exception e)
                {
                    var k = e.Message;
                }

                res = success + "-" + "ExceptionOccured";
                return res;

            }
        }


        public class RequestClass
        {
            public string flag { get; set; }
            public string vrn { get; set; }
            public string etcCustId { get; set; }
            public string rechargeTxnid { get; set; }
            public string rechargeAmt { get; set; }
        }

        public class APIFormat
        {
            public string reqdata { get; set; }
            public string msgid { get; set; }
        }

        public class RegisterClass
        {
            public string flag { get; set; }
            public string vrn { get; set; }
            public string etcCustId { get; set; }
        }




        public class VehicleInfo
        {
            public string respCode { get; set; }
            public string respMessage { get; set; }
            public string flag { get; set; }
            public List<data> data { get; set; }

        }
        public class data
        {
            public string vrn { get; set; }
            public string tagStatus { get; set; }
            public string barCode { get; set; }
        }


        public class CustomerInfo
        {
            public string respCode { get; set; }
            public string respMessage { get; set; }
            public string flag { get; set; }
            public List<CustData> data { get; set; }
        }

        public class CustData
        {
            public string walletBalance { get; set; }
            public string mobileNum { get; set; }
            public string vrn { get; set; }
            public string vehicleClass { get; set; }
            public string customerName { get; set; }
            public string masterBalance { get; set; }
            public string sdBalance { get; set; }
        }



        public class RechargeWalletResponse
        {
            public string resCode { get; set; }
            public string resMsg { get; set; }
            public string txnDateTime { get; set; }
            public string rechargeTxnid { get; set; }
            public string wltxnId { get; set; }
            public string etcCustId { get; set; }
            

        }



        public class VehicleParams
        {
            public string vrn { get; set; }
        }

        public class WalletRecharge
        {
            public int Id { get; set; }
            public string VehicleRegNo { get; set; }
            public string Amount { get; set; }
            public string FromAccountNumber { get; set; }
            public string ToAccountNumber { get; set; }
            public string PaymentType { get; set; }
            public string ReferenceNumber { get; set; }



        }



        class HTTPRequest
        {
            public string postXMLData(string destinationUrl, string requestXml)
            {
                //Bypass SSL Verification
                ServicePointManager.ServerCertificateValidationCallback +=
                    delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors) { return true; };

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(destinationUrl);
                byte[] bytes;
                bytes = System.Text.Encoding.ASCII.GetBytes(requestXml);


                request.ContentType = "application/xml";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream responseStream = response.GetResponseStream();
                    string responseStr = new StreamReader(responseStream).ReadToEnd();
                    return responseStr;

                }
                return null;
            }

        }

    }









}

