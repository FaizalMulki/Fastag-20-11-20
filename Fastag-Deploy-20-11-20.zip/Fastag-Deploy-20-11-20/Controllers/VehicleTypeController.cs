﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using OrchestratorAsset.Web.CustomModel;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vigilance.Web;

namespace OrchestratorAsset.Web.Controllers
{
    [NoDirectAccessAttribute]
    public class VehicleTypeController : Controller
    {
        // GET: VehicleType
        public ActionResult Index()
        {
            return View();
        }

        public string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }
        public object GetAllVehicles(KendoGrid grid)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {

                try
                {
                    MySqlCommand cmd = new MySqlCommand("GetAllVehicles", connection);
                    cmd.Parameters.AddWithValue("Search", grid.Search);
                    cmd.Parameters.AddWithValue("p_iPageIndex", grid.page);
                    cmd.Parameters.AddWithValue("p_iPageSize", grid.pagesize);
                    cmd.Parameters.AddWithValue("p_iTotalCount", SqlDbType.Int);
                    cmd.Parameters["p_iTotalCount"].Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    List<VehicleTypeList> groups = new List<VehicleTypeList>();

                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        groups = CommonMethod.ConvertToList<VehicleTypeList>(dt);

                    }

                    var page = new PagedData();
                    if (groups.Any())
                    {
                        page.Result = JsonConvert.SerializeObject(groups);
                        page.Total = Convert.ToInt32(cmd.Parameters["p_iTotalCount"].Value);

                    }

                    return Json(page, JsonRequestBehavior.AllowGet);

                }
                catch (Exception e)
                {
                    var k = e.Message;
                }
            }
            return null;

        }


        public string SubmitInfo(VehicleTypeModel model)
        {

            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    var fullName = "";

                    var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
                    if (loginFromAD.ToLower().Trim() == "yes")
                    {

                        fullName = Session["FullName"].ToString();


                    }
                    else
                    {
                        fullName = ConfigurationManager.AppSettings["DummyUserName"];

                    }




                    try
                    {

                        if (model.Id == 0)
                        {

                            var checkNameExists = context.VehicleType.Where(p => p.Type.ToLower().Trim() == model.Type.ToLower().Trim() && p.IsDeleted == false).FirstOrDefault();

                            if (checkNameExists != null)
                            {
                                return "exists";
                            }
                            else
                            {
                                VehicleType vt = new VehicleType();
                                vt.Type = model.Type;

                                vt.IsDeleted = false;
                                vt.CreatedBy = fullName;
                                vt.CreatedDate = DateTime.Now;
                                context.VehicleType.Add(vt);
                                context.SaveChanges();
                                return "success";
                            }

                        }
                        else
                        {

                            var checkNameExists = context.VehicleType.Where(p => p.Type.ToLower().Trim() == model.Type.ToLower().Trim() && p.IsDeleted == false && p.Id != model.Id).FirstOrDefault();

                            if (checkNameExists != null)
                            {
                                return "exists";
                            }
                            else
                            {

                                VehicleType prodToUpdate = context.VehicleType
                              .Where(p => p.Id == model.Id).FirstOrDefault();

                                if (prodToUpdate != null)
                                {
                                    prodToUpdate.Type = model.Type;
                                    prodToUpdate.ModifiedBy = fullName;
                                    prodToUpdate.ModifiedDate = DateTime.Now;

                                    context.SaveChanges();
                                    return "success";
                                }
                            }

                        }

                    }
                    catch (Exception e)
                    {
                        return "error";
                    }
                }
            }

            return "error";
        }


        [HttpPost]
        public string Delete(VehicleType model)
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                using (MyDBContext context = new MyDBContext(connection, false))
                {
                    try
                    {
                        var checkStatus = context.Setting.Where(x => x.VehicleTypeId == model.Id && x.IsDeleted == false).Count();
                        if (checkStatus > 0)
                        {
                            return "dependency";
                        }

                        var checkRegStatus = context.Registration.Where(x => x.VehicleTypeId == model.Id && x.IsDeleted == false).Count();
                        if (checkRegStatus > 0)
                        {
                            return "dependency";
                        }

                        var record = context.VehicleType.Where(x => x.Id == model.Id).FirstOrDefault().IsDeleted = true;
                        context.SaveChanges();
                        return "success";
                    }
                    catch (Exception e)
                    {
                        var k = e.Message;

                    }
                }
            }
            return "error";
        }



    }
}